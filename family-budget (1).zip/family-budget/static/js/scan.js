/* Scan page: camera / upload, validation, save through the Python API */
const CATS = ["Groceries", "Transport", "Utilities", "Health", "Other"];
let me = null, members = [], month = "", summary = [], expenses = [], blob = null, stream = null, pending = null, lastAlert = null;

const localToday = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const money = n => Number(n).toLocaleString("ru-RU");

/* ---------- start ---------- */
(async () => {
  const r = await api("/api/me");
  if (!r.ok) { location.href = "/"; return; }
  me = r.data;
  $("date").value = localToday();
  $("date").max = localToday();
  month = localToday().slice(0, 7);
  $("month").value = month;
  applyLang();
  await refresh();
})();

onLang(() => {
  const cur = $("cat").value || "Groceries";
  $("cat").innerHTML = CATS.map(k => `<option value="${k}">${t("cats")[k]}</option>`).join("");
  $("cat").value = cur;
  if (me) $("who").textContent = `${me.name} (${t(me.role)}) · ${t("hc")}: ${me.invite_code}`;
  if (lastAlert) showAlert(lastAlert.category, lastAlert.percent);
  render();
});

$("btnLogout").onclick = async () => { await api("/api/logout", { method: "POST" }); location.href = "/"; };

async function refresh() {
  const q = "?month=" + encodeURIComponent(month);
  const [s, e, m] = await Promise.all([api("/api/summary" + q), api("/api/expenses" + q), api("/api/members")]);
  summary = s.ok ? s.data : [];
  expenses = e.ok ? e.data : [];
  members = m.ok ? m.data : [];
  render();
}
$("month").onchange = () => { if ($("month").value) { month = $("month").value; refresh(); } };
$("btnExport").onclick = () => { location.href = "/api/export.csv?month=" + encodeURIComponent(month); };

/* ---------- camera / file ---------- */
function setPhoto(b) {
  blob = b;
  $("preview").src = URL.createObjectURL(b);
  $("preview").style.display = "block";
}
function handleImage(url) {
  const img = new Image();
  img.onload = () => {
    const s = Math.min(1, 1000 / Math.max(img.width, img.height));
    const c = document.createElement("canvas");
    c.width = img.width * s; c.height = img.height * s;
    c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    c.toBlob(b => setPhoto(b), "image/jpeg", 0.75);
    readCode(img);
    URL.revokeObjectURL(url);
  };
  img.src = url;
}
async function readCode(img) {
  if (!("BarcodeDetector" in window)) return;
  try {
    const r = await new BarcodeDetector().detect(img);
    if (r.length) { $("codeInfo").textContent = t("code") + r[0].rawValue; $("codeInfo").style.display = "block"; }
  } catch (e) {}
}
$("btnFile").onclick = () => $("file").click();
$("file").onchange = e => { const f = e.target.files[0]; if (f) handleImage(URL.createObjectURL(f)); };
$("btnCam").onclick = async () => {
  $("camErr").style.display = "none";
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
    $("video").srcObject = stream;
    await $("video").play();
    $("video").style.display = "block";
    $("camActions").style.display = "flex";
  } catch (e) { $("camErr").textContent = t("camErr"); $("camErr").style.display = "block"; }
};
function stopCam() {
  if (stream) stream.getTracks().forEach(tr => tr.stop());
  stream = null;
  $("video").style.display = "none";
  $("camActions").style.display = "none";
}
$("btnStop").onclick = stopCam;
$("btnSnap").onclick = () => {
  const v = $("video"), c = document.createElement("canvas");
  c.width = v.videoWidth; c.height = v.videoHeight;
  c.getContext("2d").drawImage(v, 0, 0);
  c.toBlob(b => { handleImage(URL.createObjectURL(b)); stopCam(); }, "image/jpeg");
};

/* ---------- save ---------- */
function paintErrors(errors) {
  ["date", "amount", "category", "photo"].forEach(k => {
    const box = $("e-" + k);
    box.textContent = errors[k] ? errText(errors[k]) : "";
  });
  $("date").setAttribute("aria-invalid", errors.date ? "true" : "false");
  $("amount").setAttribute("aria-invalid", errors.amount ? "true" : "false");
}
function buildForm(force) {
  const fd = new FormData();
  fd.append("date", $("date").value);
  fd.append("amount", $("amount").value);
  fd.append("category", $("cat").value);
  fd.append("store", $("store").value);
  fd.append("note", $("note").value);
  if (blob) fd.append("photo", blob, "receipt.jpg");
  if (force) fd.append("force", "1");
  return fd;
}
async function send(fd) {
  ["saved", "alert90", "formErr", "dup"].forEach(id => { $(id).style.display = "none"; });
  const r = await api("/api/expenses", { method: "POST", body: fd });
  if (r.status === 409 && r.data.duplicate) {
    pending = fd;
    $("dupText").textContent = t("dup") + " (" + r.data.existing + ")";
    $("dup").style.display = "block";
    return;
  }
  if (!r.ok) {
    const errors = r.data.errors || { server: "server" };
    paintErrors(errors);
    if (errors.server || errors.auth) { $("formErr").textContent = errText(errors.server || errors.auth); $("formErr").style.display = "block"; }
    return;
  }
  paintErrors({});
  pending = null;
  $("form").reset();
  $("date").value = localToday();
  blob = null;
  $("preview").style.display = "none";
  $("codeInfo").style.display = "none";
  $("saved").textContent = t("savedOk") + " " + r.data.expense.id;
  $("saved").style.display = "block";
  lastAlert = r.data.percent >= 90 ? { category: r.data.category, percent: r.data.percent } : null;
  if (lastAlert) showAlert(lastAlert.category, lastAlert.percent);
  await refresh();
}
function showAlert(cat, p) {
  $("alert90").textContent = t("warn").replace("%c", t("cats")[cat]).replace("%p", p) + (p > 100 ? " " + t("over") : "");
  $("alert90").style.display = "block";
}
$("form").onsubmit = e => { e.preventDefault(); send(buildForm(false)); };
$("dupKeep").onclick = () => {
  if (!pending) return;
  pending.set("force", "1");
  send(pending);
};
$("dupDiscard").onclick = () => { pending = null; $("dup").style.display = "none"; };

/* ---------- display ---------- */
function render() {
  const isAdmin = me && me.role === "admin";
  $("total").textContent = money(summary.reduce((a, s) => a + s.spent, 0)) + " ₸";
  $("members").innerHTML = `<ul class="members">` + members.map(m =>
    `<li><span>${esc(m.name)}</span><small>${t(m.role)}</small></li>`).join("") + "</ul>";
  $("limitBox").innerHTML = summary.map(s => {
    const pct = Math.round(s.spent / s.limit * 100);
    const edit = isAdmin
      ? `<input type="number" min="1" step="1000" value="${s.limit}" data-limit="${s.category}" aria-label="${esc(t("cats")[s.category])}">`
      : `${money(s.limit)}`;
    return `<div><div class="limit-row"><strong>${t("cats")[s.category]}</strong>
      <span>${money(s.spent)} / ${edit} ₸ (${t("used")} ${pct}%)</span></div>
      <div class="bar"><span class="${pct >= 90 ? "hot" : ""}" style="width:${Math.min(100, pct)}%"></span></div></div>`;
  }).join("");

  if (!expenses.length) { $("list").innerHTML = `<p class="empty">${t("none")}</p>`; return; }
  $("list").innerHTML = "<table><tbody>" + expenses.map(x => `<tr>
    <td>${x.photo ? `<img class="thumb" src="${x.photo}" alt="" data-open="${x.photo}">` : ""}</td>
    <td>${x.id}<br><small>${x.date}</small></td>
    <td>${money(x.amount)} ₸<br><small>${t("cats")[x.category]}${x.store ? " · " + esc(x.store) : ""} · ${esc(x.by)}</small></td>
    <td>${isAdmin ? `<button data-del="${x.pk}">${t("del")}</button>` : ""}</td></tr>`).join("") + "</tbody></table>";
}
$("list").onclick = async e => {
  const d = e.target.dataset;
  if (d.open) window.open(d.open, "_blank");
  if (d.del) { await api("/api/expenses/" + d.del, { method: "DELETE" }); await refresh(); }
};
$("limitBox").onchange = async e => {
  const cat = e.target.dataset.limit;
  if (!cat) return;
  await api("/api/limits", jsonOpts("PUT", { category: cat, limit: parseInt(e.target.value, 10) }));
  await refresh();
};
