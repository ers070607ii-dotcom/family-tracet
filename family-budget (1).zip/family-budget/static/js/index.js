/* Opening page: register / login */
const fieldIds = { name: "r-name", email: "r-email", household_code: "r-code", password: "r-pass", mismatch: "r-pass2" };
let lastErrors = {};

function showTab(which) {
  const reg = which === "reg";
  $("tabReg").setAttribute("aria-selected", reg);
  $("tabLogin").setAttribute("aria-selected", !reg);
  $("regForm").classList.toggle("hidden", !reg);
  $("loginForm").classList.toggle("hidden", reg);
}
$("tabReg").onclick = () => showTab("reg");
$("tabLogin").onclick = () => showTab("login");

$("r-role").onchange = () => $("codeBox").classList.toggle("hidden", $("r-role").value !== "member");

function paintErrors(errors) {
  lastErrors = errors;
  Object.keys(fieldIds).forEach(k => {
    const box = $("e-" + k), input = $(fieldIds[k]);
    box.textContent = errors[k] ? errText(errors[k]) : "";
    if (input) input.setAttribute("aria-invalid", errors[k] ? "true" : "false");
  });
}
onLang(() => paintErrors(lastErrors));

$("regForm").onsubmit = async e => {
  e.preventDefault();
  $("regErr").style.display = "none";
  const body = {
    name: $("r-name").value, email: $("r-email").value, role: $("r-role").value,
    household_code: $("r-code").value, password: $("r-pass").value
  };
  if ($("r-pass").value !== $("r-pass2").value) { paintErrors({ mismatch: "mismatch" }); return; }
  const r = await api("/api/register", jsonOpts("POST", body));
  if (r.ok) { location.href = "/scan"; return; }
  const errors = r.data.errors || { server: "server" };
  paintErrors(errors);
  if (errors.server || errors.role) { $("regErr").textContent = errText(errors.server || errors.role); $("regErr").style.display = "block"; }
};

$("loginForm").onsubmit = async e => {
  e.preventDefault();
  $("loginErr").style.display = "none";
  const r = await api("/api/login", jsonOpts("POST", { email: $("l-email").value, password: $("l-pass").value }));
  if (r.ok) { location.href = "/scan"; return; }
  const code = (r.data.errors && (r.data.errors.login || r.data.errors.server)) || "server";
  $("loginErr").textContent = errText(code);
  $("loginErr").style.display = "block";
};

applyLang();
