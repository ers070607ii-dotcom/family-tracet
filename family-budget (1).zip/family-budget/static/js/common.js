/* Shared: translations (kk / ru / en), language switcher and API helper */
const T = {
  kk: {
    title: "Отбасы бюджетін бірге жүргізіңіз",
    subtitle: "Чекті сканерлеңіз, шығыс өз санатына түседі, ал айлық лимит 90%-ға жеткенде ескерту аласыз.",
    f1: "Чекті планшетпен сканерлеу", f2: "Санаттар бойынша айлық лимиттер", f3: "Лимиттің 90%-ында ескерту",
    tabReg: "Тіркелу", tabLogin: "Кіру",
    name: "Аты-жөні", email: "Электрондық пошта", role: "Рөліңіз",
    roleAdmin: "Үй әкімшісі (бюджетті басқарады)", roleMember: "Отбасы мүшесі",
    hcode: "Үй коды (әкімшіден алыңыз)", pass: "Құпиясөз", pass2: "Құпиясөзді қайталаңыз",
    register: "Тіркелу", login: "Кіру",
    err_name: "Аты-жөніңізді енгізіңіз.", err_email: "Дұрыс электрондық пошта енгізіңіз.",
    err_password: "Құпиясөз кемінде 8 таңбадан тұруы керек.", err_mismatch: "Құпиясөздер сәйкес емес.",
    err_role: "Рөлді таңдаңыз.", err_household_code: "Үй коды дұрыс емес.",
    err_email_taken: "Бұл пошта тіркелген.", err_bad_login: "Пошта немесе құпиясөз қате.",
    err_date: "Күнді YYYY-MM-DD форматында енгізіңіз, болашақ күн болмайды.",
    err_amount: "Сома 0-ден үлкен болуы керек.", err_category: "Санатты таңдаңыз.",
    err_photo: "Тек JPG, PNG немесе WEBP суреті.", err_forbidden: "Мұны тек үй әкімшісі жасай алады.",
    err_server: "Сервер қатесі. Кейінірек қайталаңыз.",
    dTitle: "Чекті сканерлеу", dSub: "Чектің суретін түсіріңіз немесе жүктеңіз, деректерді тексеріп, сақтаңыз.",
    openCam: "Камераны ашу", upload: "Суретті таңдау", snap: "Түсіру", stop: "Жабу",
    date: "Сатып алу күні", amount: "Сома (₸)", cat: "Санат", store: "Дүкен (міндетті емес)", note: "Ескерту (міндетті емес)",
    save: "Чекті сақтау", limits: "Айлық лимиттер", history: "Сақталған чектер", none: "Әзірге чек жоқ.",
    keep: "Сақтау", discard: "Болдырмау", dup: "Мұндай шығыс бұрыннан бар. Сол чек қайта сканерленген бе?",
    savedOk: "Чек сақталды.", warn: "Назар аударыңыз: «%c» санатының лимиті %p%-ға жетті.", over: "Лимит асып кетті!",
    camErr: "Камераға қол жеткізу мүмкін емес. «Суретті таңдау» батырмасын қолданыңыз.",
    code: "Чек коды оқылды: ", del: "Жою", used: "пайдаланылды", logout: "Шығу", hc: "Үй коды",
    admin: "әкімші", member: "мүше",
    month: "Ай", total: "Айдағы жалпы шығыс", exportCsv: "CSV жүктеу", family: "Отбасы мүшелері",
    how: "Қалай жұмыс істейді",
    h1: "Тіркеліңіз", h1t: "Үй әкімшісі үй кодын алады, отбасы мүшелері сол кодпен қосылады.",
    h2: "Чекті сканерлеңіз", h2t: "Суретке түсіріп, күнін, соманы және санатты тексеріңіз.",
    h3: "Лимитті бақылаңыз", h3t: "Санат лимиттің 90%-на жеткенде жүйе ескертеді.",
    cats: { Groceries: "Азық-түлік", Transport: "Көлік", Utilities: "Коммуналдық", Health: "Денсаулық", Other: "Басқа" }
  },
  ru: {
    title: "Ведите семейный бюджет вместе",
    subtitle: "Сканируйте чек, и расход попадёт в нужную категорию. При 90% месячного лимита придёт предупреждение.",
    f1: "Сканирование чеков на планшете", f2: "Месячные лимиты по категориям", f3: "Предупреждение при 90% лимита",
    tabReg: "Регистрация", tabLogin: "Вход",
    name: "Имя и фамилия", email: "Электронная почта", role: "Ваша роль",
    roleAdmin: "Администратор дома (управляет бюджетом)", roleMember: "Член семьи",
    hcode: "Код дома (получите у администратора)", pass: "Пароль", pass2: "Повторите пароль",
    register: "Зарегистрироваться", login: "Войти",
    err_name: "Введите имя и фамилию.", err_email: "Введите корректный адрес электронной почты.",
    err_password: "Пароль должен содержать не менее 8 символов.", err_mismatch: "Пароли не совпадают.",
    err_role: "Выберите роль.", err_household_code: "Неверный код дома.",
    err_email_taken: "Эта почта уже зарегистрирована.", err_bad_login: "Неверная почта или пароль.",
    err_date: "Введите дату в формате YYYY-MM-DD, не из будущего.",
    err_amount: "Сумма должна быть больше 0.", err_category: "Выберите категорию.",
    err_photo: "Только изображения JPG, PNG или WEBP.", err_forbidden: "Это может сделать только администратор дома.",
    err_server: "Ошибка сервера. Повторите позже.",
    dTitle: "Сканирование чека", dSub: "Сфотографируйте или загрузите чек, проверьте данные и сохраните.",
    openCam: "Открыть камеру", upload: "Выбрать фото", snap: "Снять", stop: "Закрыть",
    date: "Дата покупки", amount: "Сумма (₸)", cat: "Категория", store: "Магазин (необязательно)", note: "Заметка (необязательно)",
    save: "Сохранить чек", limits: "Месячные лимиты", history: "Сохранённые чеки", none: "Чеков пока нет.",
    keep: "Сохранить", discard: "Отменить", dup: "Такой расход уже есть. Возможно, этот чек отсканирован дважды?",
    savedOk: "Чек сохранён.", warn: "Внимание: лимит категории «%c» достиг %p%.", over: "Лимит превышен!",
    camErr: "Нет доступа к камере. Используйте кнопку «Выбрать фото».",
    code: "Код чека считан: ", del: "Удалить", used: "использовано", logout: "Выйти", hc: "Код дома",
    admin: "админ", member: "член семьи",
    month: "Месяц", total: "Всего расходов за месяц", exportCsv: "Скачать CSV", family: "Члены семьи",
    how: "Как это работает",
    h1: "Зарегистрируйтесь", h1t: "Администратор дома получает код, члены семьи присоединяются по этому коду.",
    h2: "Отсканируйте чек", h2t: "Сфотографируйте чек и проверьте дату, сумму и категорию.",
    h3: "Следите за лимитами", h3t: "Когда категория достигает 90% лимита, система предупредит.",
    cats: { Groceries: "Продукты", Transport: "Транспорт", Utilities: "Коммунальные", Health: "Здоровье", Other: "Другое" }
  },
  en: {
    title: "Track your family budget together",
    subtitle: "Scan a receipt and the expense lands in the right category. Get a warning when a monthly limit reaches 90%.",
    f1: "Scan receipts on the shared tablet", f2: "Monthly limits for each category", f3: "Alert at 90% of the limit",
    tabReg: "Sign up", tabLogin: "Log in",
    name: "Full name", email: "Email", role: "Your role",
    roleAdmin: "Household admin (manages the budget)", roleMember: "Family member",
    hcode: "Household code (ask your admin)", pass: "Password", pass2: "Repeat password",
    register: "Sign up", login: "Log in",
    err_name: "Enter your full name.", err_email: "Enter a valid email address.",
    err_password: "Password must be at least 8 characters.", err_mismatch: "Passwords do not match.",
    err_role: "Choose a role.", err_household_code: "Household code is not valid.",
    err_email_taken: "This email is already registered.", err_bad_login: "Wrong email or password.",
    err_date: "Enter the date as YYYY-MM-DD, not in the future.",
    err_amount: "Amount must be greater than 0.", err_category: "Choose a category.",
    err_photo: "Only JPG, PNG or WEBP images.", err_forbidden: "Only the household admin can do this.",
    err_server: "Server error. Try again later.",
    dTitle: "Scan receipt", dSub: "Take or upload a receipt photo, check the details, then save.",
    openCam: "Open camera", upload: "Choose photo", snap: "Capture", stop: "Close",
    date: "Purchase date", amount: "Amount (₸)", cat: "Category", store: "Store (optional)", note: "Note (optional)",
    save: "Save receipt", limits: "Monthly limits", history: "Saved receipts", none: "No receipts yet.",
    keep: "Keep", discard: "Discard", dup: "The same purchase is already logged. Was this receipt scanned twice?",
    savedOk: "Receipt saved.", warn: "Heads up: the “%c” limit has reached %p%.", over: "Limit exceeded!",
    camErr: "Camera is not available. Use the “Choose photo” button.",
    code: "Receipt code read: ", del: "Delete", used: "used", logout: "Log out", hc: "Household code",
    admin: "admin", member: "member",
    month: "Month", total: "Total spent this month", exportCsv: "Download CSV", family: "Family members",
    how: "How it works",
    h1: "Sign up", h1t: "The household admin gets a code and family members join with it.",
    h2: "Scan a receipt", h2t: "Take a photo and check the date, amount and category.",
    h3: "Watch your limits", h3t: "When a category reaches 90% of its limit, you get a warning.",
    cats: { Groceries: "Groceries", Transport: "Transport", Utilities: "Utilities", Health: "Health", Other: "Other" }
  }
};

let lang = "kk";
try { lang = localStorage.getItem("lang") || "kk"; } catch (e) {}
const langHooks = [];
const $ = id => document.getElementById(id);
const t = k => T[lang][k] || k;
const errText = code => t("err_" + code);

function applyLang() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach(el => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll(".langs button").forEach(b => b.setAttribute("aria-pressed", b.dataset.lang === lang));
  langHooks.forEach(fn => fn());
}
function onLang(fn) { langHooks.push(fn); }
document.querySelectorAll(".langs button").forEach(b => b.addEventListener("click", () => {
  lang = b.dataset.lang;
  try { localStorage.setItem("lang", lang); } catch (e) {}
  applyLang();
}));

async function api(url, opts = {}) {
  try {
    const r = await fetch(url, opts);
    let data = {};
    try { data = await r.json(); } catch (e) {}
    return { ok: r.ok, status: r.status, data };
  } catch (e) {
    return { ok: false, status: 0, data: { errors: { server: "server" } } };
  }
}
const jsonOpts = (method, body) => ({ method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
function esc(s) { return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
