// Service worker for the installable app.
// Only static files (CSS/JS/icons) are cached. Pages and receipt photos contain private
// family data, so they are never stored: they always come from the server.
const CACHE = "fbt-static-v1";
const PRECACHE = ["/offline", "/static/style.css", "/static/app.js", "/static/icons/icon-192.png"];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((c) => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  if (url.pathname.startsWith("/static/")) {           // stale-while-revalidate
    event.respondWith(
      caches.open(CACHE).then(async (cache) => {
        const cached = await cache.match(req);
        const fresh = fetch(req).then((res) => { if (res.ok) cache.put(req, res.clone()); return res; }).catch(() => cached);
        return cached || fresh;
      })
    );
    return;
  }

  if (req.mode === "navigate") {                        // pages: network, friendly offline fallback
    event.respondWith(fetch(req).catch(() => caches.match("/offline")));
  }
});
