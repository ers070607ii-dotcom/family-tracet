document.addEventListener("DOMContentLoaded", () => {
  const palette = ["#168657","#4d91e9","#f6ad45","#a37bdc","#9caaa2"];
  function makeChart(id, data, type="doughnut") {
    const canvas = document.getElementById(id);
    if (!canvas || typeof Chart === "undefined") return;
    const labels = Object.keys(data || {});
    const values = labels.map(k => Number(data[k] || 0));
    new Chart(canvas, {
      type, data: { labels, datasets: [{ data: values, backgroundColor: palette,
        borderWidth: type === "doughnut" ? 2 : 0, borderRadius: type === "bar" ? 6 : 0,
        hoverOffset: 7 }] },
      options: { responsive:true, maintainAspectRatio:false,
        plugins:{ legend:{display:false} },
        scales: type === "bar" ? {y:{beginAtZero:true,grid:{color:"#edf1ee"}},x:{grid:{display:false}}} : {} }
    });
  }
  makeChart("categoryChart", window.budgetData || {});
  makeChart("reportChart", window.reportData || {}, "bar");
});

/* ---------- Installable app (PWA) ---------- */
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(() => {}));
}
let installPrompt = null;
window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  installPrompt = e;
  const btn = document.getElementById("installBtn"), hint = document.getElementById("installHint");
  if (btn) { btn.hidden = false; if (hint) hint.hidden = true; }
});
document.addEventListener("click", (e) => {
  if (e.target && e.target.id === "installBtn" && installPrompt) {
    installPrompt.prompt();
    installPrompt.userChoice.finally(() => { installPrompt = null; e.target.hidden = true; });
  }
});

/* ---------- Receipt scan page ---------- */
document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("receiptInput");
  if (!input) return;                                   // not the upload step
  const $ = (id) => document.getElementById(id);
  const form = $("scanForm"), preview = $("preview"), dropText = $("dropText"),
        submit = $("submitBtn"), busy = $("busy"), zone = $("dropzone");
  const MAX_SIDE = 2000;

  $("takePhoto").addEventListener("click", () => { input.setAttribute("capture", "environment"); input.click(); });
  $("pickFile").addEventListener("click", () => { input.removeAttribute("capture"); input.click(); });

  // Phone photos are 3-8 MB. Shrink to ~2000px before upload: faster, and well under the server limit.
  async function shrink(file) {
    if (!file.type.startsWith("image/")) return file;
    try {
      const url = URL.createObjectURL(file);
      const img = await new Promise((ok, fail) => { const i = new Image(); i.onload = () => ok(i); i.onerror = fail; i.src = url; });
      const scale = Math.min(1, MAX_SIDE / Math.max(img.naturalWidth, img.naturalHeight));
      if (scale === 1 && file.size < 3 * 1024 * 1024) { URL.revokeObjectURL(url); return file; }
      const c = document.createElement("canvas");
      c.width = Math.round(img.naturalWidth * scale); c.height = Math.round(img.naturalHeight * scale);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      const blob = await new Promise((ok) => c.toBlob(ok, "image/jpeg", 0.9));
      return blob ? new File([blob], "receipt.jpg", { type: "image/jpeg" }) : file;
    } catch (_) { return file; }                        // e.g. HEIC the browser can't draw: send the original
  }

  async function useFile(file) {
    if (!file) return;
    const ready = await shrink(file);
    const dt = new DataTransfer(); dt.items.add(ready); input.files = dt.files;
    preview.src = URL.createObjectURL(ready); preview.hidden = false;
    dropText.textContent = "Выбрано: " + (file.name || "фото");
    submit.disabled = false;
  }

  input.addEventListener("change", () => useFile(input.files[0]));
  ["dragenter", "dragover"].forEach((ev) => zone.addEventListener(ev, (e) => { e.preventDefault(); zone.classList.add("over"); }));
  ["dragleave", "drop"].forEach((ev) => zone.addEventListener(ev, (e) => { e.preventDefault(); zone.classList.remove("over"); }));
  zone.addEventListener("drop", (e) => useFile(e.dataTransfer.files[0]));

  form.addEventListener("submit", () => { busy.hidden = false; submit.disabled = true; });
  window.addEventListener("pageshow", () => { busy.hidden = true; });   // back button after OCR
});
