# Family Budget Tracker

Flask + SQLite family budget app with **receipt scanning (OCR)** and an **installable phone app (PWA)**.

## Run it (Python 3.10+)

```bash
pip install -r requirements.txt
python app.py            # http://127.0.0.1:5000
```
Demo login: `demo@family.kz` / `family123` (see "Before going public" below).

## Receipt scanning needs Tesseract

The Python packages are not enough: install the Tesseract program too, **with Russian and Kazakh language data**.

| System | Install |
|---|---|
| Windows | Installer from https://github.com/UB-Mannheim/tesseract/wiki. In the installer, open "Additional language data" and tick **Russian** and **Kazakh**. If it is not found, set `TESSERACT_CMD` to the full path of `tesseract.exe`. |
| macOS | `brew install tesseract tesseract-lang` |
| Ubuntu/Debian | `sudo apt install tesseract-ocr tesseract-ocr-rus tesseract-ocr-kaz` (if your distro has no `-kaz` package, put `kaz.traineddata` from the `tessdata_fast` repo into the tessdata folder) |

Open **Settings** in the app: the "Распознавание чеков (OCR)" row shows the detected version and languages.
Without Tesseract the app still works: the photo is saved and you fill the fields by hand.

### How scanning works
1. Take or choose a photo on the **Скан чека** page (it is shrunk in the browser first).
2. The server straightens/crops/cleans the image and runs OCR in several passes. The amount is marked
   "confident" only if independent passes agree.
3. You review a pre-filled form (date, amount, category, comment) next to the photo and save it.
   The photo stays attached to the expense (🧾 link in the list).

OCR can still misread digits, especially on blurry, faded or tilted photos, so always compare the amount with the photo.
Tips: dark flat background, good light, receipt filling most of the frame.

## Use it as a phone app

**Quick test on the same Wi-Fi:** `HOST=0.0.0.0 python app.py` (Windows PowerShell: `$env:HOST="0.0.0.0"; python app.py`),
then open `http://<your-PC-IP>:5000` on the phone. Scanning with the camera works this way.

**Install as an app** (home-screen icon, full screen, long-press shortcut "Сканировать чек") needs **HTTPS**:
browsers only allow service workers and installation on secure origins (localhost excepted).
- Android/Chrome: menu ⋮ → *Install app*, or the button in Settings.
- iPhone/Safari: Share → *Add to Home Screen*.

Ways to get HTTPS: deploy the Docker image below behind any HTTPS host, or use a tunnel such as Cloudflare Tunnel / ngrok for a quick test.

## Deploy with Docker

```bash
docker build -t family-budget .
docker run -p 8000:8000 -v budget-data:/data -e SECRET_KEY="$(openssl rand -hex 32)" family-budget
```
`/data` holds the database and receipt photos; keep it on a volume. `DATA_DIR` changes this location.
(The Docker image has not been build-tested by the author; the app and OCR were tested directly.)

## Before going public
- Set a real `SECRET_KEY` (the default in `app.py` is only for local use).
- A fresh database is seeded with the demo user above. Register your own account and remove or change the demo one.
- Receipt photos are private (served only to their owner) and are never cached by the service worker.

## Tests
```bash
pip install pytest
pytest            # parser tests + end-to-end scan flow (needs Tesseract with rus)
```

## Files
`app.py` routes · `receipt_ocr.py` image clean-up, OCR, parsing · `templates/scan.html` scan UI ·
`static/sw.js`, `static/manifest.webmanifest`, `static/icons/` the phone-app parts.
