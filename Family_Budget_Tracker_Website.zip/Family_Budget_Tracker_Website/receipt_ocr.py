"""Receipt scanning for Family Budget Tracker.

Pipeline:  photo  ->  clean-up (rotation, contrast, lighting)  ->  Tesseract OCR
           ->  parser that finds total / date / store / category.

The parser is pure Python (no OCR needed) so it can be unit-tested on plain text.
"""
import os
import re
import shutil
from dataclasses import dataclass, asdict
from datetime import date, timedelta

from PIL import Image, ImageChops, ImageFilter, ImageOps

try:
    import pytesseract
except ImportError:  # app still runs; scan page falls back to manual entry
    pytesseract = None

MAX_SIDE = 2000          # stored/processed image is shrunk to this (phones shoot 4000+ px)
OCR_LANGS = ("rus", "kaz", "eng")   # used when installed, in this order
MAX_AMOUNT = 10_000_000


class OCRUnavailable(RuntimeError):
    """Tesseract (or pytesseract) is not installed on this machine."""


# --------------------------------------------------------------------------- #
# Tesseract setup
# --------------------------------------------------------------------------- #
def _configure_tesseract():
    if pytesseract is None:
        raise OCRUnavailable("pytesseract is not installed (pip install pytesseract)")
    cmd = os.environ.get("TESSERACT_CMD")
    if not cmd and not shutil.which("tesseract"):
        # typical Windows install location
        for guess in (r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                      r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"):
            if os.path.exists(guess):
                cmd = guess
                break
    if cmd:
        pytesseract.pytesseract.tesseract_cmd = cmd
    try:
        return pytesseract.get_tesseract_version()
    except Exception as exc:  # TesseractNotFoundError and friends
        raise OCRUnavailable("Tesseract is not installed or not on PATH") from exc


def ocr_status():
    """Small dict for the Settings page: is OCR usable and with which languages."""
    try:
        version = _configure_tesseract()
        installed = set(pytesseract.get_languages(config=""))
        langs = [l for l in OCR_LANGS if l in installed]
        return {"available": True, "version": str(version), "langs": langs,
                "missing": [l for l in OCR_LANGS if l not in installed]}
    except OCRUnavailable as exc:
        return {"available": False, "error": str(exc), "langs": [], "missing": list(OCR_LANGS)}


def _lang_string():
    installed = set(pytesseract.get_languages(config=""))
    langs = [l for l in OCR_LANGS if l in installed]
    return "+".join(langs) if langs else "eng"


# --------------------------------------------------------------------------- #
# Image handling
# --------------------------------------------------------------------------- #
def load_image(file_like):
    """Open an uploaded image safely: fix phone rotation, drop EXIF/GPS, cap size."""
    img = Image.open(file_like)
    img.load()                                   # raises on corrupt / non-image data
    img = ImageOps.exif_transpose(img)
    if img.mode in ("RGBA", "LA", "P"):
        bg = Image.new("RGB", img.size, "white")
        bg.paste(img.convert("RGBA"), mask=img.convert("RGBA").split()[-1])
        img = bg
    else:
        img = img.convert("RGB")
    if max(img.size) > MAX_SIDE:
        img.thumbnail((MAX_SIDE, MAX_SIDE), Image.LANCZOS)
    return img


def _otsu_threshold(gray_small):
    hist = gray_small.histogram()
    total = sum(hist)
    sum_all = sum(i * h for i, h in enumerate(hist))
    best_t, best_var, w_b, sum_b = 128, -1.0, 0, 0
    for t in range(256):
        w_b += hist[t]
        if w_b == 0:
            continue
        w_f = total - w_b
        if w_f == 0:
            break
        sum_b += t * hist[t]
        m_b, m_f = sum_b / w_b, (sum_all - sum_b) / w_f
        var = w_b * w_f * (m_b - m_f) ** 2
        if var > best_var:
            best_var, best_t = var, t
    return best_t


def _crop_to_paper(gray):
    """If the receipt is a bright sheet on a darker background, crop to it so the text
    gets more pixels. Returns the image unchanged when no clear paper region is found."""
    w, h = gray.size
    small = gray.resize((300, max(1, int(300 * h / w))), Image.BILINEAR)
    thr = _otsu_threshold(small)
    mask = small.point(lambda p: 255 if p > thr else 0).filter(ImageFilter.MedianFilter(7))
    box = mask.getbbox()
    if not box:
        return gray
    sx = w / small.size[0]
    sy = h / small.size[1]
    l, t, r, b = box
    area = (r - l) * (b - t) / (small.size[0] * small.size[1])
    if area < 0.08 or area > 0.85:        # nothing receipt-like, or paper already fills the frame
        return gray
    mx, my = (r - l) * 0.04, (b - t) * 0.03
    return gray.crop((max(0, int((l - mx) * sx)), max(0, int((t - my) * sy)),
                      min(w, int((r + mx) * sx)), min(h, int((b + my) * sy))))


def _prepare_for_ocr(img, flatten_lighting=True, min_width=1400, crop=False):
    gray = ImageOps.grayscale(img)
    if crop:
        gray = _crop_to_paper(gray)
    w, h = gray.size
    if w < min_width:                             # Tesseract likes ~30px tall letters
        scale = min_width / w
        gray = gray.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
    if flatten_lighting:
        # divide-out uneven lighting / shadows: background -> ~light grey, ink stays dark
        radius = max(15, gray.size[0] // 40)
        blur = gray.filter(ImageFilter.BoxBlur(radius))
        gray = ImageChops.subtract(gray, blur, 1.0, 235)
    gray = ImageOps.autocontrast(gray, cutoff=1)
    return gray.filter(ImageFilter.SHARPEN)


def _run_tesseract(img, psm, lang):
    return pytesseract.image_to_string(img, lang=lang, config=f"--psm {psm} --oem 1")


# --------------------------------------------------------------------------- #
# Parsing
# --------------------------------------------------------------------------- #
@dataclass
class ParsedReceipt:
    amount: float | None = None
    amount_confidence: str = "none"      # high | medium | low | none
    purchase_date: str = ""              # ISO yyyy-mm-dd
    date_found: bool = False
    merchant: str = ""
    category: str = "Other"
    raw_text: str = ""

    def as_dict(self):
        return asdict(self)


# total keywords, best first. (priority, regex)
_TOTAL_KEYWORDS = [
    (3, re.compile(r"к\s*оплат|оплате|төлеуге|төленетін|amount\s*due|to\s*pay|grand\s*total")),
    (2, re.compile(r"ит[оo0][гr]|жиын|барлы[гғ]ы|всего|total")),
    (1, re.compile(r"сумма|sum\b")),
]
# lines that mention a total word but are NOT the grand total
_NOT_TOTAL = re.compile(
    r"ндс|nds|vat|сдач|change|скидк|бонус|подыт|промеж|subtotal|округл|получено|внесено|"
    r"предоплат|аванс|позиц|товаров|количеств|кол-во|кол\.|шт\b")
# lines whose numbers are IDs, not money (used only for the "no keyword" fallback)
_ID_LINE = re.compile(r"иин|бин|рнн|инн|знм|ккм|зн\b|тел|т\.|№|чек\s*\d|касс|фп|фд|смена|сайт|www|http|адрес|ул\.|пр\.")

_DATE_TIME = re.compile(r"\b\d{1,4}[./-]\d{1,2}[./-]\d{2,4}\b|\b\d{1,2}:\d{2}(?::\d{2})?\b")
_AMOUNT = re.compile(r"""
    (?<![\d.,])
    (?:\d{1,3}(?:[ \u00a0\u202f]\d{3})+ | \d{1,3}(?:[.,]\d{3})+ | \d+)
    (?:[.,]\d{1,2})?
    (?!\d)
""", re.X)

_CATEGORY_KEYWORDS = {
    "Groceries": ["magnum", "магнум", "small", "смолл", "galmart", "галмарт", "anvar", "анвар", "arbuz",
                  "арбуз", "рамстор", "ramstore", "светофор", "супермаркет", "гипермаркет", "гастроном",
                  "продукт", "базар", "рынок", "хлеб", "молок", "мясо", "овощ", "фрукт", "минимаркет",
                  "metro cash", "дастархан", "ярмарк", "бакалея"],
    "Transport": ["такси", "taxi", "yandex go", "яндекс go", "indrive", "indriver", "индрайв", "бензин",
                  "аи-92", "аи-95", "аи 92", "аи 95", "ai-92", "ai-95", "дизель", "азс", "helios", "гелиос",
                  "sinooil", "qazaq oil", "qazaqoil", "газпром", "gazprom", "shell", "petroleum", "автобус",
                  "проезд", "onay", "онай", "парковк", "стоянк", "топлив"],
    "Utilities": ["электро", "коммунал", "водоканал", "водоснабж", "отоплен", "теплоснаб", "газоснаб",
                  "alseco", "алсеко", "казахтелеком", "kazakhtelecom", "beeline", "билайн", "kcell", "кселл",
                  "activ", "tele2", "теле2", "altel", "алтел", "интернет", "квартплат", "кск", "свет"],
    "Health": ["аптек", "дәріхана", "дарихана", "pharm", "фарм", "europharma", "еврофарм", "клиник",
               "емхана", "больниц", "стоматолог", "dental", "лаборатор", "invivo", "olymp", "олимп",
               "medical", "медицин", "врач", "лекарств", "витамин"],
}


def _clean_lines(text):
    lines = []
    for raw in text.replace("\r", "\n").split("\n"):
        line = re.sub(r"[ \t]+", " ", raw.replace("\u00a0", " ")).strip()
        if line:
            lines.append(line)
    return lines


def _to_float(token):
    """'18 450,00' -> 18450.0 ; '1,234.50' -> 1234.5 ; '5.430' -> 5430.0"""
    s = token.replace("\u00a0", "").replace("\u202f", "").replace(" ", "")
    m = re.fullmatch(r"(\d{1,3}(?:[.,]\d{3})+|\d+)(?:[.,](\d{1,2}))?", s)
    if not m:
        return None
    integer, dec = m.group(1), m.group(2)
    integer = re.sub(r"[.,]", "", integer)
    try:
        value = float(f"{integer}.{dec}" if dec else integer)
    except ValueError:
        return None
    return value if 0 < value <= MAX_AMOUNT else None


def _amounts_in(line):
    """All plausible money values in a line, in order of appearance (dates/times removed)."""
    stripped = _DATE_TIME.sub(" ", line)
    values = []
    for m in _AMOUNT.finditer(stripped):
        v = _to_float(m.group(0))
        if v is not None:
            values.append((v, m.group(0)))
    return values


def find_total(lines):
    """Return (amount, confidence) for the receipt's grand total."""
    best = None  # (priority, line_index, amount)
    for i, line in enumerate(lines):
        low = line.lower().replace("ё", "е")
        if _NOT_TOTAL.search(low):
            continue
        for priority, rx in _TOTAL_KEYWORDS:
            km = rx.search(low)
            if not km:
                continue
            after = line[km.end():] if km.end() < len(line) else ""
            vals = _amounts_in(after) or _amounts_in(line[km.start():])
            if not vals and i + 1 < len(lines):                # amount wrapped onto next line
                vals = _amounts_in(lines[i + 1])
            if vals:
                # largest value on the line: a trailing "₸"/"тг" is often misread as a stray digit
                cand = (priority, i, max(v for v, _ in vals))
                if best is None or (cand[0], cand[1]) > (best[0], best[1]):
                    best = cand
            break  # highest-priority keyword on this line decides
    if best:
        return best[2], ("high" if best[0] >= 2 else "medium")

    # Fallback: biggest plausible money-looking number outside ID/phone lines.
    pool = []
    for line in lines:
        low = line.lower()
        if _ID_LINE.search(low) or _NOT_TOTAL.search(low):
            continue
        for v, tok in _amounts_in(line):
            if re.search(r"[.,]\d{2}$", tok) or " " in tok or v >= 100:
                pool.append(v)
    return (max(pool), "low") if pool else (None, "none")


def find_date(text, today=None):
    today = today or date.today()
    oldest = today - timedelta(days=365 * 3)
    patterns = [
        (re.compile(r"(?<!\d)(\d{1,2})[./-](\d{1,2})[./-](\d{4})(?!\d)"), "dmy"),
        (re.compile(r"(?<!\d)(\d{4})[./-](\d{1,2})[./-](\d{1,2})(?!\d)"), "ymd"),
        (re.compile(r"(?<![\d.])(\d{1,2})[./-](\d{1,2})[./-](\d{2})(?![\d])"), "dmy2"),
    ]
    found = []
    for rx, kind in patterns:
        for m in rx.finditer(text):
            a, b, c = (int(x) for x in m.groups())
            try:
                if kind == "dmy":
                    d = date(c, b, a)
                elif kind == "ymd":
                    d = date(a, b, c)
                else:
                    d = date(2000 + c, b, a)
            except ValueError:
                continue
            if oldest <= d <= today:
                found.append((m.start(), d))
    if not found:
        return None
    return min(found)[1]          # earliest position in the text = header date


def find_merchant(lines):
    skip = re.compile(r"чек|касс|фискал|ккм|иин|бин|рнн|инн|тел|www|http|товарн|добро|спасибо|"
                      r"кассир|смена|ofd|офд|адрес|^г\.|\bул\.|\bпр\.|\bпр-т|\bмкр|\bд\.\s*\d|\d{5,}", re.I)
    legal = re.compile(r"^(тоо|too|ип|ip|ао|ao|тов|llp|ooo|ооо)\b[\s.\-]*", re.I)
    for line in lines[:8]:
        if skip.search(line):
            continue
        name = legal.sub("", line)
        name = re.sub(r"[^\w\s.\-&'\"«»]", "", name, flags=re.U).strip(" \"'«»")
        letters = sum(ch.isalpha() for ch in name)
        if letters >= 3 and letters >= len(name) * 0.5:
            return name[:40]
    return ""


def guess_category(text):
    low = text.lower().replace("ё", "е")
    scores = {cat: sum(1 for kw in kws if kw in low) for cat, kws in _CATEGORY_KEYWORDS.items()}
    cat, score = max(scores.items(), key=lambda kv: kv[1])
    return cat if score > 0 else "Other"


def parse_receipt_text(text, today=None):
    lines = _clean_lines(text)
    amount, conf = find_total(lines)
    d = find_date(text, today)
    return ParsedReceipt(
        amount=amount,
        amount_confidence=conf,
        purchase_date=(d or (today or date.today())).isoformat(),
        date_found=d is not None,
        merchant=find_merchant(lines),
        category=guess_category(text),
        raw_text=text.strip(),
    )


# --------------------------------------------------------------------------- #
# Public entry point
# --------------------------------------------------------------------------- #
# (crop to paper, flatten lighting, tesseract page-segmentation mode, upscale width)
_PASSES = [(True, True, 6, 1400), (False, False, 6, 1400), (True, False, 6, 2000),
           (True, True, 6, 2200), (False, True, 4, 1400)]
_RANK = {"high": 3, "medium": 2, "low": 1, "none": 0}


def _combine(results):
    """Merge several OCR passes. A single pass can misread a digit, so the amount is only
    'high' confidence when at least two differently-processed passes agree on it."""
    from collections import Counter

    votes = Counter(r.amount for r in results if r.amount is not None)
    amount, conf = None, "none"
    if votes:
        top = max(votes.values())
        tied = [a for a, n in votes.items() if n == top]
        # tie-break: best parser confidence, then earliest pass
        amount = max(tied, key=lambda a: (max(_RANK[r.amount_confidence] for r in results if r.amount == a),
                                          -min(i for i, r in enumerate(results) if r.amount == a)))
        base = max(_RANK[r.amount_confidence] for r in results if r.amount == amount)
        if top >= 2 and base >= 2:
            conf = "high"
        elif base >= 2:
            conf = "medium"       # only one pass found it, or passes disagree: user should check
        else:
            conf = "low"

    date_votes = Counter(r.purchase_date for r in results if r.date_found)
    if date_votes:
        top = max(date_votes.values())
        best_date = next(r.purchase_date for r in results if r.date_found and date_votes[r.purchase_date] == top)
        date_found = True
    else:
        best_date, date_found = results[0].purchase_date, False

    all_text = "\n".join(r.raw_text for r in results)
    return ParsedReceipt(
        amount=amount,
        amount_confidence=conf,
        purchase_date=best_date,
        date_found=date_found,
        merchant=next((r.merchant for r in results if r.merchant), ""),
        category=guess_category(all_text),
        raw_text=results[0].raw_text,
    )


def scan_receipt(img, today=None):
    """OCR a PIL image and return a ParsedReceipt. Raises OCRUnavailable if no Tesseract."""
    _configure_tesseract()
    lang = _lang_string()
    results = []
    for crop, flatten, psm, width in _PASSES:
        prepared = _prepare_for_ocr(img, flatten_lighting=flatten, min_width=width, crop=crop)
        results.append(parse_receipt_text(_run_tesseract(prepared, psm, lang), today))
        # Stop early once two passes agree on the amount and a date was found.
        if len(results) >= 2:
            c = _combine(results)
            if c.amount_confidence == "high" and c.date_found:
                break
    return _combine(results)
