"""End-to-end test of the scan flow through Flask's test client (temp database, real Tesseract)."""
import importlib, io, os, sys, tempfile
import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
RECEIPT = os.environ.get("TEST_RECEIPT", os.path.join(ROOT, "tests", "sample_receipt.jpg"))


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("DATA_DIR", str(tmp_path))
    import app as app_module
    importlib.reload(app_module)
    app_module.app.config["TESTING"] = True
    c = app_module.app.test_client()
    r = c.post("/login", data={"email": "demo@family.kz", "password": "family123"})
    assert r.status_code == 302
    c.app_module = app_module
    return c


def test_pages_render(client):
    for path in ["/dashboard", "/expenses", "/scan", "/settings", "/reports", "/family", "/budget", "/about"]:
        assert client.get(path).status_code == 200, path


def test_pwa_files(client):
    m = client.get("/manifest.webmanifest")
    assert m.status_code == 200 and m.mimetype == "application/manifest+json"
    sw = client.get("/sw.js")
    assert sw.status_code == 200 and "javascript" in sw.mimetype
    assert client.get("/offline").status_code == 200
    assert client.get("/static/icons/icon-512.png").status_code == 200


def test_full_scan_flow(client):
    with open(RECEIPT, "rb") as f:
        r = client.post("/scan", data={"receipt": (f, "r.jpg")}, content_type="multipart/form-data")
    html = r.get_data(as_text=True)
    assert r.status_code == 200 and "Проверьте данные чека" in html
    assert 'value="7500"' in html and "2026-11-12" in html
    import re
    fname = re.search(r'name="receipt_file" value="([^"]+)"', html).group(1)
    assert client.get(f"/receipts/{fname}").status_code == 200

    r = client.post("/scan/confirm", data={"receipt_file": fname, "amount": "7500", "purchase_date": "2026-11-12",
                                           "category": "Groceries", "note": "Чек: Magnum"})
    assert r.status_code == 302
    assert fname in client.get("/expenses").get_data(as_text=True)      # receipt link shown

    # same purchase again -> duplicate warning, then allowed with the checkbox
    data = {"receipt_file": fname, "amount": "7500", "purchase_date": "2026-11-12", "category": "Groceries"}
    r = client.post("/scan/confirm", data=data)
    assert "confirm_duplicate" in r.get_data(as_text=True)
    assert client.post("/scan/confirm", data={**data, "confirm_duplicate": "yes"}).status_code == 302


def test_receipts_are_private(client):
    assert client.get("/receipts/1_" + "a" * 32 + ".jpg").status_code == 404      # missing
    assert client.get("/receipts/..%2Fbudget.db").status_code == 404              # traversal
    anon = client.application.test_client()
    assert anon.get("/receipts/1_" + "a" * 32 + ".jpg").status_code == 302       # login required


def test_bad_inputs(client):
    r = client.post("/scan", data={"receipt": (io.BytesIO(b"not an image"), "x.jpg")}, content_type="multipart/form-data")
    assert r.status_code == 302                                                    # friendly error, no crash
    r = client.post("/scan/confirm", data={"receipt_file": "x", "amount": "1"})
    assert r.status_code == 302
    r = client.post("/expenses", data={"amount": "nan", "purchase_date": "2026-11-01", "category": "Other"})
    assert r.status_code == 200                                                    # NaN no longer crashes
