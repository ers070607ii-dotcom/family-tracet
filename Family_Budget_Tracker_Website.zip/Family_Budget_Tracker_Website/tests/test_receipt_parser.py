import os
import sys
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from receipt_ocr import find_date, find_total, parse_receipt_text, _clean_lines, _to_float  # noqa: E402

TODAY = date(2026, 11, 17)

MAGNUM = """ТОО "Magnum Cash&Carry"
БИН 980940000123
г. Алматы, пр. Абая 44
Кассовый чек № 4821
Дата: 12.11.2026 18:42
Молоко 3.2% 1л        2 x 480.00     960.00
Хлеб Бородинский      1 x 220.00     220.00
Мясо говядина 1.2кг                 6 840.00
Подытог                             8 020.00
Скидка                               -520.00
ИТОГО К ОПЛАТЕ:                     7 500.00
Наличными                          10 000.00
Сдача                               2 500.00
В т.ч. НДС 12%                        803.57
"""

PHARMACY = """Аптека Europharma
ИИН/БИН 051240001234
Чек №0034
15.11.2026 09:15
Парацетамол 500мг       450,00
Витамин С               1 250,00
ИТОГО: 1 700,00
Банковская карта 1 700,00
"""

FUEL = """Helios АЗС №12
2026-11-10 07:55
АИ-95  32.4 л x 289.00
Сумма 9 363.60
Итого
9 363.60
"""

NO_KEYWORD = """Магазин
12.11.2026
Товар 1  1 500.00
Товар 2  2 300.00
"""


def test_total_after_subtotal_discount_and_change():
    p = parse_receipt_text(MAGNUM, TODAY)
    assert p.amount == 7500.00
    assert p.amount_confidence == "high"      # the "к оплате" line, not Подытог / Наличными / НДС
    assert p.purchase_date == "2026-11-12"
    assert p.category == "Groceries"
    assert "Magnum" in p.merchant


def test_pharmacy_comma_decimals_and_category():
    p = parse_receipt_text(PHARMACY, TODAY)
    assert p.amount == 1700.00
    assert p.purchase_date == "2026-11-15"
    assert p.category == "Health"
    assert "Europharma" in p.merchant


def test_amount_on_next_line_and_iso_date_and_fuel():
    p = parse_receipt_text(FUEL, TODAY)
    assert p.amount == 9363.60
    assert p.purchase_date == "2026-11-10"
    assert p.category == "Transport"


def test_fallback_when_no_total_keyword_is_flagged_low():
    p = parse_receipt_text(NO_KEYWORD, TODAY)
    assert p.amount == 2300.00
    assert p.amount_confidence == "low"


def test_nothing_found():
    p = parse_receipt_text("blurry nonsense text", TODAY)
    assert p.amount is None and p.amount_confidence == "none"
    assert p.date_found is False and p.purchase_date == "2026-11-17"
    assert p.category == "Other"


def test_id_numbers_are_not_mistaken_for_money():
    lines = _clean_lines("БИН 980940000123\nИИН 123456789012\nЗНМ 0100123456\nИТОГО 4 200.00")
    assert find_total(lines) == (4200.0, "high")


def test_number_formats():
    assert _to_float("18 450,00") == 18450.0
    assert _to_float("18450.00") == 18450.0
    assert _to_float("1,234.50") == 1234.5
    assert _to_float("5.430") == 5430.0
    assert _to_float("0") is None


def test_future_and_ancient_dates_are_ignored():
    assert find_date("01.01.2030", TODAY) is None
    assert find_date("01.01.2015", TODAY) is None
    assert find_date("Дата 05.11.26", TODAY) == date(2026, 11, 5)
    assert find_date("31.02.2026", TODAY) is None      # invalid calendar date
